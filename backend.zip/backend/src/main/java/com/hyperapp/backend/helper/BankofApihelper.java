package com.hyperapp.backend.helper;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.hyperapp.backend.dao.AccountSummaryRepository;
import com.hyperapp.backend.dao.CreditCardSummaryRepository;
import com.hyperapp.backend.dao.LoanSummaryRepository;
import com.hyperapp.backend.dao.TransactionRepository;
import com.hyperapp.backend.model.Transaction;
import com.hyperapp.backend.model.AccountSummary;
import com.hyperapp.backend.model.CreditCardSummary;
import com.hyperapp.backend.model.LoanSummary;
@Component
public class BankofApihelper {

	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	TransactionRepository transactionRepo;
	
	@Autowired
	AccountSummaryRepository accountSummaryRepo;
		
	@Autowired
	LoanSummaryRepository loanSummaryRepo;
	
	@Autowired
	CreditCardSummaryRepository creditcardSummaryRepo;
	
	public void saveMockAccountSummaryH2() {
		accountSummaryRepo.deleteAll();
		accountSummaryRepo.save(new AccountSummary("1","$23589"));
	}
	
	public void saveMockCreditCardSummaryH2() {
		creditcardSummaryRepo.deleteAll();
		creditcardSummaryRepo.save(new CreditCardSummary("1","$9258"));
	}
	
	public void saveMockLoanSummaryH2() {
		loanSummaryRepo.deleteAll();
		loanSummaryRepo.save(new LoanSummary("1","$5536"));
	}
	
	
	public void saveMockTransactionH2() {
		transactionRepo.deleteAll();
		transactionRepo.save(new Transaction("1","XXXXXXX555","Radisson Towers", "Online Transaction", "IMPS DEBIT","$850","26/07/2023 11:53:00","4 day ago", "Rent"));
		transactionRepo.save(new Transaction("2","XXXXXXX555","Bangalore Cafe", "PhonePe UPI", "UPI DEBIT","$250","27/07/2023 11:53:00","3 day ago", "Food"));
//		transactionRepo.save(new Transaction("1","XXXXXXX555","Bangalore Cafe", "PhonePe UPI", "UPI DEBIT","$250","27/07/2023 11:53:00","3 day ago", "Food"));
//		transactionRepo.save(new Transaction("2","XXXXXXX555","Radisson Towers", "Online Transaction", "IMPS DEBIT","$850","26/07/2023 11:53:00","4 day ago", "Rent"));
		transactionRepo.save(new Transaction("3","XXXXXXX555","Apple Inc", "Credit Card Transaction", "CREDIT CARD DEBIT","$850","26/07/2023 16:53:00","4 day ago", "Shopping"));
		transactionRepo.save(new Transaction("4","XXXXXXX555","HDFC Ltd", "Direct Debit Transaction", "MORTGAGE DIRECT DEBIT","$980","25/07/2023 16:53:00","5 day ago", "Home Loan EMI"));
		transactionRepo.save(new Transaction("5","XXXXXXX555","Natwest Bank", "VERIFICATION", "APPLICATION","$980","24/07/2023 16:53:00","6 day ago", "Joint Account"));
		transactionRepo.save(new Transaction("6","XXXXXXX555","Lexus Showroom, Chennai", "Cheque Transaction", "CHEQUE DEBIT","$45000","21/07/2023 16:53:00","9 day ago", "Purchase"));
		transactionRepo.save(new Transaction("7","XXXXXXX555","Credit Card", "Account", "Credit Card","$45000","21/07/2023 16:53:00","9 day ago", "Settlement"));
			
	}
	
	//Transaction List from BankofAPI domain
	
	public void getSaveBankofApiTransaction() {
        
		//Retrieve Access Token
		String url4 = "https://ob.sandbox.natwest.com/token";
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		MultiValueMap<String,Object> requestBody = new LinkedMultiValueMap<>();
		requestBody.add("grant_type", "client_credentials");
		requestBody.add("client_id", "laI89ACiT9PDToTKfxCjSxc1HnS6_xo0SMUQS9eq4Ls=");
		requestBody.add("client_secret", "rHplStResfKDoqNzo5Jhiwe1oyddQLmsfn5i3AqKmAU=");
		requestBody.add("scope", "accounts");
		
		HttpEntity<Object> requestEntity = new HttpEntity<>(requestBody, headers);			
		ResponseEntity<Object> responseEntity = restTemplate.exchange(
		    		url4,
		            HttpMethod.POST,
		            requestEntity,
		            Object.class
		    );
		LinkedHashMap<String, String> output = (LinkedHashMap<String, String>) responseEntity.getBody();
		//LinkedHashMap<String, Integer> output = (LinkedHashMap<String, Integer>) responseEntity.getBody();
		//System.out.println(output.get("access_token").toString()  );
		//Retrieve Access Token
		
		
		//POST ACTION REQUEST
		String url5 = "https://ob.sandbox.natwest.com/open-banking/v3.1/aisp/account-access-consents";
		HttpHeaders headers1 = new HttpHeaders();
		headers1.setContentType(MediaType.APPLICATION_JSON );
		headers1.setBearerAuth(output.get("access_token").toString());
		headers1.setContentLength(206);
		String requestBody1 = "{\"Data\":{\"Permissions\":[\"ReadAccountsDetail\",\"ReadBalances\",\"ReadTransactionsCredits\",\"ReadTransactionsDebits\",\"ReadTransactionsDetail\"]},\"Risk\":{}}";
		HttpEntity<String> requestEntity1 = new HttpEntity<String>(requestBody1, headers1);
		ResponseEntity<Object> responseEntity1 = restTemplate.exchange(
		  		url5,
		          HttpMethod.POST,
		          requestEntity1,
		          Object.class
		  );
		LinkedHashMap<String, Object> output1 = (LinkedHashMap<String, Object>) responseEntity1.getBody();
		LinkedHashMap<String, String> output11 = (LinkedHashMap<String, String>) output1.get("Data");
		// System.out.println(output11.get("ConsentId"));
		//POST ACTION REQUEST
		
		
		//APPROVE CONSENT
		String redirectUri = "https://3b7a09c6-8fe3-41a1-b3bc-0e206cbe0004.example.org/redirect";
		
		String url6 = "https://api.sandbox.natwest.com/authorize";
        Map<String, String> uriParam = new HashMap<>();
        UriComponents builder = UriComponentsBuilder.fromHttpUrl(url6)
		                  .queryParam("client_id","laI89ACiT9PDToTKfxCjSxc1HnS6_xo0SMUQS9eq4Ls=")
		                          .queryParam("response_type","code id_token")
		                          .queryParam("scope","openid accounts")
		                          .queryParam("redirect_uri",redirectUri)
		                          .queryParam("state","ABC")
		                          .queryParam("request",output11.get("ConsentId").toString())
		                          .queryParam("authorization_mode","AUTO_POSTMAN")
		                          .queryParam("authorization_username","123456789012@3b7a09c6-8fe3-41a1-b3bc-0e206cbe0004.example.org")
		                          .build();
        ResponseEntity<Object> responseEntity2 = restTemplate.exchange(builder.toUriString() , HttpMethod.GET, HttpEntity.EMPTY, Object.class);
		LinkedHashMap<String, String> output2 = (LinkedHashMap<String, String>) responseEntity2.getBody();
		//System.out.println(output2.get("redirectUri")  );
		  
		  
		String outputUri = output2.get("redirectUri").toString().replaceFirst("(?:#)+", "?")  ;
		MultiValueMap<String, String> parameters =
		          UriComponentsBuilder.fromUriString(outputUri).build().getQueryParams();
		List<String> param1 = parameters.get("code");
		String authorizationCode  = param1.get(0);
		//System.out.println("param1: " + param1.get(0)); 
		//APPROVE CONSENT
	
		  
		  
		//CODE EXCHANGE
		String url7 = "https://ob.sandbox.natwest.com/token";
		HttpHeaders headers2 = new HttpHeaders();
		headers2.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		  MultiValueMap<String,Object> requestBody2 = new LinkedMultiValueMap<>();
		requestBody2.add("client_id", "laI89ACiT9PDToTKfxCjSxc1HnS6_xo0SMUQS9eq4Ls=");
		requestBody2.add("client_secret", "rHplStResfKDoqNzo5Jhiwe1oyddQLmsfn5i3AqKmAU=");
		requestBody2.add("redirect_uri", output2.get("redirectUri").toString());
		requestBody2.add("grant_type", "authorization_code");
		requestBody2.add("code", authorizationCode);
		
		HttpEntity<Object> requestEntity2 = new HttpEntity<>(requestBody2, headers2);			
		ResponseEntity<Object> responseEntity3 = restTemplate.exchange(
		      		url7,
		              HttpMethod.POST,
		              requestEntity2,
		              Object.class
		      );
		 
		LinkedHashMap<String, String> output3 = (LinkedHashMap<String, String>) responseEntity3.getBody();
		//System.out.println(output3.get("access_token").toString()  );
		//CODE EXCHANGE
		  
		  
		//GET ACCOUNT LIST
		String url8 = "https://ob.sandbox.natwest.com/open-banking/v3.1/aisp/accounts";	
		HttpHeaders headers3 = new HttpHeaders();
		headers3.setBearerAuth(output3.get("access_token").toString());
		MultiValueMap<String,Object> requestBody3 = new LinkedMultiValueMap<>();
		HttpEntity<Object> requestEntity3 = new HttpEntity<>(requestBody3, headers3);
		ResponseEntity<Object> responseEntity4 = restTemplate.exchange(
			    url8,
		            HttpMethod.GET,
		            requestEntity3,
		            Object.class
		    );
		LinkedHashMap<String, Object> output4 = (LinkedHashMap<String, Object>) responseEntity4.getBody();
		LinkedHashMap<String, Object> output41 = (LinkedHashMap<String, Object>) output4.get("Data") ;				  
		List<Object> output42 =  (List<Object>) output41.get("Account") ;
		LinkedHashMap<String, String> output43 = (LinkedHashMap<String, String>) output42.get(1);
		//System.out.println(output43.get("AccountId").toString());
		//GET ACCOUNT LIST
		
		
		//GET ACCOUNT TRANSACTIONS		  
		String url9 = "https://ob.sandbox.natwest.com/open-banking/v3.1/aisp/accounts/"+output43.get("AccountId").toString()+"/transactions";	
		HttpHeaders headers4 = new HttpHeaders();
		headers4.setBearerAuth(output3.get("access_token").toString());
		MultiValueMap<String,Object> requestBody4 = new LinkedMultiValueMap<>();
		HttpEntity<Object> requestEntity4 = new HttpEntity<>(requestBody4, headers4);
		ResponseEntity<Object> responseEntity5 = restTemplate.exchange(
			    url9,
		            HttpMethod.GET,
		            requestEntity4,
		            Object.class
		    );
		
	    if (responseEntity5.getStatusCode() == HttpStatus.OK) 
	    {

			LinkedHashMap<String, Object> output5 = (LinkedHashMap<String, Object>) responseEntity5.getBody();
			LinkedHashMap<String, Object> output51 = (LinkedHashMap<String, Object>) output5.get("Data") ;				  
			List<Object> output52 =  (List<Object>) output51.get("Transaction") ;
			
			//LinkedHashMap<String, Object> output53 = (LinkedHashMap<String, Object>) output52.get(0);
			//System.out.println(output53.get("TransactionId").toString());
			//GET ACCOUNT TRANSACTIONS
			
			
			
			for(int i = 0 ; i < output52.size() ; i++){
				int cnt = i;
				
			LinkedHashMap<String, Object> output53 = (LinkedHashMap<String, Object>) output52.get(i);
			//System.out.println(output53.get("TransactionId").toString());
			//System.out.println(output53.get("CreditDebitIndicator").toString());
			//System.out.println(output53.get("TransactionInformation").toString());
			LinkedHashMap<String, String> output54 = (LinkedHashMap<String, String>) output53.get("Amount");
			//System.out.println(output54.get("Amount").toString());
			//System.out.println("//");
				
			cnt = cnt + 20;
				
			transactionRepo.save(new Transaction(Integer.toString(cnt),"XXXXXXX555",output53.get("TransactionId").toString(), "Online Transaction", output53.get("CreditDebitIndicator").toString().toUpperCase(),output54.get("Amount").toString(),"15/03/2022 10:59:60","1 year ago" , output53.get("TransactionInformation").toString()));
			
		    }
						
    	}  		
	
	}
}
