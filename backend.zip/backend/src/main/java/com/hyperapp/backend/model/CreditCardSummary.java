package com.hyperapp.backend.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CreditCardSummary")
public class CreditCardSummary {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long Id;
	

	private String Rid;
	private String creditOutstanding;
	
	public CreditCardSummary() {
			//default constructor
    }
	
	 public String getRid() {
		return Rid;
	 }
	 
	 public void setRid(String Rid) {
			this.Rid = Rid;
	 }
	 
	 public String getCreditOutstanding() {
		return creditOutstanding;
	 }
	 
	 public void setCreditOutstanding(String creditOutstanding) {
			this.creditOutstanding = creditOutstanding;
	 }
	
	 public CreditCardSummary(String Rid,
	            String creditOutstanding) 
	 {
	 super();
	 this.Rid = Rid;
	 this.creditOutstanding = creditOutstanding;
	
  }

}
