package com.hyperapp.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hyperapp.backend.dao.AccountSummaryRepository;
import com.hyperapp.backend.dao.CreditCardSummaryRepository;
import com.hyperapp.backend.dao.LoanSummaryRepository;
import com.hyperapp.backend.dao.TransactionRepository;
import com.hyperapp.backend.model.AccountSummary;
import com.hyperapp.backend.model.CreditCardSummary;
import com.hyperapp.backend.model.LoanSummary;
import com.hyperapp.backend.model.Transaction;



@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class TransactionController {

	@Autowired
	TransactionRepository transactionRepo;
	
	@Autowired
	AccountSummaryRepository accountSummaryRepo;
		
	@Autowired
	LoanSummaryRepository loanSummaryRepo;
	
	@Autowired
	CreditCardSummaryRepository creditcardSummaryRepo;
	
	@GetMapping("/health")
	public String checkHealth() {
		return "I am working fine";
	}
	
	
	//Transaction List from H2
	@GetMapping("/transactionlist")
	public List<Transaction> listOfTransactions() {
		//h2TableData();
		
		return transactionRepo.findAll();
		
	}
	
	//Account Summary List from H2
	@GetMapping("/accountsummary")
	public List<AccountSummary> accountSummary() {
		//h2TableData();
		
		return accountSummaryRepo.findAll();
		
	}
	
	//CreditCard Summary List from H2
	@GetMapping("/creditcardummary")
	public List<CreditCardSummary> creditcardummary() {
		//h2TableData();
		
		return creditcardSummaryRepo.findAll();  
		
	}
	
	//Account Summary List from H2
	@GetMapping("/loansummary")
	public List<LoanSummary> loanSummary() {
		//h2TableData();
		
		return loanSummaryRepo.findAll();  
		
	}
		
}
