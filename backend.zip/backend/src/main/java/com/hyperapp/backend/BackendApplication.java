package com.hyperapp.backend;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.hyperapp.backend.helper.*;


@SpringBootApplication
public class BackendApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(BackendApplication.class, args);
	}
	

	@Autowired
	BankofApihelper bankofApiTransactions;

	
	@Override
	public void run(String... args) throws Exception {
		bankofApiTransactions.saveMockTransactionH2();
		bankofApiTransactions.getSaveBankofApiTransaction();
		bankofApiTransactions.saveMockAccountSummaryH2();
		bankofApiTransactions.saveMockLoanSummaryH2();
		bankofApiTransactions.saveMockCreditCardSummaryH2();
		
	}
	
	
}