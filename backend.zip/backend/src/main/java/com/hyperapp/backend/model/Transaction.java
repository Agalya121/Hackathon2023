package com.hyperapp.backend.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Transaction")
public class Transaction {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long Id;
	

	private String Rid;
	
	private String transactionMode;		
	private String transactionFrom;
	private String transactionTo;
	private String transactionCateogry;
	private String transactionAmount;
	private String transactionDate;
	private String transactionAwayMin;
	private String transactionForWhat;
				
	 public Transaction() {
				//default constructor
	 }
	 
	 
	 public String getRid() {
		return Rid;
	 }
	 
	 public void setRid(String Rid) {
			this.Rid = Rid;
	 }
	 
	 
	 public String gettransactionMode() {
		return transactionMode;
	 }
	 
	 public void settransactionMode(String transactionMode) {
			this.transactionMode = transactionMode;
	 }
	
	 public String getTransactionCategory() {
			return transactionCateogry;
	 }
	
	 public void setTransactionCategory(String transactionCateogry) {
			this.transactionCateogry = transactionCateogry;
	 }
	 
	 public String getTransactionFrom() {
			return transactionFrom;
	 }
	
	 public void setTransactionFrom(String transactionFrom) {
			this.transactionFrom = transactionFrom;
	 }
	 
	 public String getTransactionTo() {
			return transactionTo;
	 }
	 
	 public void setTransactionTo(String transactionTo) {
			this.transactionTo = transactionTo;
	 }
	
 
	 public String getTransactionAmount() {
			return transactionAmount;
	 }
	
	 public void setTransactionAmount(String transactionAmount) {
			this.transactionAmount = transactionAmount;
	 }
	 
	 public String getTransactionDate() {
			return transactionDate;
	 }
	
	 public void setTransactionDate(String transactionDate) {
			this.transactionDate = transactionDate;
	 }
     
	 
	 public String getTransactionAwayMin() {
			return transactionAwayMin;
	 }
	
	 public void setTransactionAwayMin(String transactionAwayMin) {
			this.transactionAwayMin = transactionAwayMin;
	 }
	 
	 

	 public String getTransactionForWhat() {
			return transactionForWhat;
	 }
	
	 public void setTransactionForWhat(String transactionForWhat) {
			this.transactionForWhat = transactionForWhat;
	 }
	 
	 public Transaction(String Rid,
			            String transactionFrom, 
			            String transactionTo,
			            String transactionMode,
			            String transactionCateogry, 
			            String transactionAmount,
			            String transactionDate,
			            String transactionAwayMin,
			            String transactionForWhat
			            ) {
			super();
			this.Rid = Rid;
			this.transactionMode = transactionMode;
			this.transactionCateogry = transactionCateogry;
			this.transactionFrom = transactionFrom;
			this.transactionTo = transactionTo;
			this.transactionAmount = transactionAmount;
			this.transactionDate = transactionDate;
			this.transactionAwayMin = transactionAwayMin;
			this.transactionForWhat = transactionForWhat;
	
	 }

		
}
