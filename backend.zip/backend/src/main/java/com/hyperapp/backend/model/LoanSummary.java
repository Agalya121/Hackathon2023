package com.hyperapp.backend.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="LoanSummary")
public class LoanSummary {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long Id;
	

	private String Rid;
	private String LoanAmount;
	
	public LoanSummary() {
			//default constructor
    }
	
	 public String getRid() {
		return Rid;
	 }
	 
	 public void setRid(String Rid) {
			this.Rid = Rid;
	 }
	 
	 public String getLoanAmount() {
		return LoanAmount;
	 }
	 
	 public void setLoanAmount(String LoanAmount) {
			this.LoanAmount = LoanAmount;
	 }
	
	 public LoanSummary(String Rid,
	            String LoanAmount) 
	 {
	 super();
	 this.Rid = Rid;
	 this.LoanAmount = LoanAmount;
	
  }

}
