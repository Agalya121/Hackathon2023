package com.hyperapp.backend.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.hyperapp.backend.model.LoanSummary;
@Repository
public interface LoanSummaryRepository extends JpaRepository<LoanSummary, Long> {

}
