package com.hyperapp.backend.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="AccountSummary")
public class AccountSummary {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long Id;
	

	private String Rid;
	private String totalAmount;
	
	 public AccountSummary() {
			//default constructor
    }
	 
	 public String getRid() {
		return Rid;
	 }
	 
	 public void setRid(String Rid) {
			this.Rid = Rid;
	 }
	 
	 public String getTotalAmount() {
		return totalAmount;
	 }
	 
	 public void setTotalAmount(String totalAmount) {
			this.totalAmount = totalAmount;
	 }
	 
	 public AccountSummary(String Rid,
	            String totalAmount) 
	 {
	 super();
	 this.Rid = Rid;
	 this.totalAmount = totalAmount;
	
     }

}
