import React, { Component } from 'react';
import GetTransactionServices from '../../services/TransactionServices';

export class Transaction extends Component {

    constructor(props) {
        super(props)
        this.state = {
          //MS CONNECT
          transaction:[],
        }
    }

    componentDidMount() {
        //your code
        //MS CONNECT
        GetTransactionServices.getTransactions().then((Response) =>{
          this.setState({transaction:Response.data})
        });
    }

    render() {
         return (
              <>
                {
                  this.state.transaction.map(
                      trxsummary => 
                      {
                          
                        // 
                        if (trxsummary.transactionCategory === "UPI DEBIT") 
                          { 
                              return (
                                    <div key = {trxsummary.rid} class="card text-center  border" style={{width:"650px",marginBottom:"10px"}}>   
                                      <div  class="card-header bg-gradient-danger"  > {trxsummary.transactionCategory}</div> 
                                      <div class="card-body" >
                                        <p  >You have made  {trxsummary.transactionCategory} Transaction of  Amount {trxsummary.transactionAmount} for {trxsummary.transactionForWhat} from {trxsummary.transactionFrom} via {trxsummary.transactionMode} to {trxsummary.transactionTo} on {trxsummary.transactionDate}</p>
                                        <a class="btn bg-danger">Share Receipt</a>
                                        <a class="btn bg-danger">Split Expense</a>
                                        <a class="btn bg-danger">Report</a>
                                      </div>
                                      <div class="card-footer text-muted"> {trxsummary.transactionAwayMin} </div>
                                    </div> 
                               ) 
                          }   
                          else if (trxsummary.transactionCategory === "IMPS DEBIT")
                          {
                                return (
                                      <div key = {trxsummary.rid} class="card text-center  border" style={{width:"650px",marginBottom:"10px"}}>   
                                        <div  class="card-header bg-gradient-success"  > {trxsummary.transactionCategory}</div> 
                                        <div class="card-body" >
                                          <p  >You have made  {trxsummary.transactionCategory} Transaction of  Amount {trxsummary.transactionAmount} for {trxsummary.transactionForWhat} from {trxsummary.transactionFrom} via {trxsummary.transactionMode} to {trxsummary.transactionTo} on {trxsummary.transactionDate}</p>
                                          <a class="btn btn-success">Make Regular</a>
                                          <a class="btn btn-success">Block Card</a>
                                          <a class="btn btn-success">Report</a>
                                        </div>
                                        <div class="card-footer text-muted"> {trxsummary.transactionAwayMin} </div>
                                      </div> 
                                 ) 
                            
                          }
                          else if (trxsummary.transactionCategory === "CREDIT CARD DEBIT")
                          {
                                return (
                                      <div key = {trxsummary.rid} class="card text-center  border" style={{width:"650px",marginBottom:"10px"}}>   
                                        <div  class="card-header bg-info"  > {trxsummary.transactionCategory}</div> 
                                        <div class="card-body" >
                                          <p>You have made  {trxsummary.transactionCategory} Transaction of  Amount {trxsummary.transactionAmount} for {trxsummary.transactionForWhat} from {trxsummary.transactionFrom} via {trxsummary.transactionMode} to {trxsummary.transactionTo} on {trxsummary.transactionDate}</p>
                                          <a class="btn bg-info">Convert to Loan </a>
                                          <a class="btn bg-info">Block Card</a>
                                          <a class="btn bg-info">Report</a>
                                        </div>
                                        <div class="card-footer text-muted"> {trxsummary.transactionAwayMin} </div>
                                      </div> 
                                 ) 
                          }
                          else if (trxsummary.transactionCategory === "MORTGAGE DIRECT DEBIT")
                          {
                                return (
                                      <div key = {trxsummary.rid} class="card text-center  border" style={{width:"650px",marginBottom:"10px"}}>   
                                        <div  class="card-header bg-primary"  > {trxsummary.transactionCategory}</div> 
                                        <div class="card-body" >
                                          <p >You have made  {trxsummary.transactionCategory} Transaction of  Amount {trxsummary.transactionAmount} for {trxsummary.transactionForWhat} from {trxsummary.transactionFrom} via {trxsummary.transactionMode} to {trxsummary.transactionTo} on {trxsummary.transactionDate}</p>
                                          <a class="btn bg-primary">Pre Payment</a>
                                          <a class="btn bg-primary">Mortgage Loan Top up</a>
                                          <a class="btn bg-primary">Report</a>
                                        </div>
                                        <div class="card-footer text-muted"> {trxsummary.transactionAwayMin} </div>
                                      </div> 
                                 ) 
                            
                          }
                          else if (trxsummary.transactionCategory === "APPLICATION")
                          {
                                return (
                                      <div key = {trxsummary.rid} class="card text-center  border" style={{width:"650px",marginBottom:"10px"}}>   
                                        <div  class="card-header bg-warning"  > {trxsummary.transactionCategory}</div> 
                                        <div class="card-body" >
                                          <p class="card-title" >You're {trxsummary.transactionCategory} for {trxsummary.transactionForWhat} with {trxsummary.transactionTo} applied on {trxsummary.transactionDate} is currently under {trxsummary.transactionMode} stage to {trxsummary.transactionTo}</p>
                                          <a class="btn bg-warning">Enquire</a>
                                          <a class="btn bg-warning">Cancel Application</a>
                                        </div>
                                        <div class="card-footer text-muted"> {trxsummary.transactionAwayMin} </div>
                                      </div> 
                                 ) 
                          }
                          else if (trxsummary.transactionCategory === "CHEQUE DEBIT")
                          {
                                return (
                                      <div key = {trxsummary.rid} class="card text-center  border" style={{width:"650px",marginBottom:"10px"}}>   
                                        <div  class="card-header bg-secondary"  > {trxsummary.transactionCategory}</div> 
                                        <div class="card-body" >
                                          <p class="card-title" >You're {trxsummary.transactionCategory} for the {trxsummary.transactionForWhat} with {trxsummary.transactionTo} wrote on {trxsummary.transactionDate} has been debited</p>
                                          <a class="btn bg-secondary">Cheque Book Request</a>
                                          <a class="btn bg-secondary">Report</a>
                                        </div>
                                        <div class="card-footer text-muted"> {trxsummary.transactionAwayMin} </div>
                                      </div> 
                                 ) 
                          }
                          else // if (trxsummary.transactionCategory === "DEBIT")
                          {
                                return (
                                      <div key = {trxsummary.rid} class="card text-center  border" style={{width:"650px",marginBottom:"10px"}}>   
                                        <div  class="card-header bg-gradient-success"  > {trxsummary.transactionCategory}</div> 
                                        <div class="card-body" >
                                          <p >You have made  {trxsummary.transactionCategory} Transaction of  Amount {trxsummary.transactionAmount} for {trxsummary.transactionForWhat} from {trxsummary.transactionFrom} via {trxsummary.transactionMode} to {trxsummary.transactionTo} on {trxsummary.transactionDate}</p>
                                          <a class="btn btn-success">Make Regular</a>
                                          <a class="btn btn-success">Block Card</a>
                                          <a class="btn btn-success">Report</a>
                                        </div>
                                        <div class="card-footer text-muted"> {trxsummary.transactionAwayMin} </div>
                                      </div> 
                                 ) 
                            
                          }


                          // 
                      }
                  )   
                }      
             </> 
         )
    }
}

export default Transaction;