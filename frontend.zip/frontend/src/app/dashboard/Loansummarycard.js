import React, { Component } from 'react';
import GetLoanSummaryService from '../../services/LoanSummaryService';

export class Loansummarycard extends Component {

    constructor(props) {
        super(props)
        this.state = {
          //MS CONNECT
          loansummary:[],
        }
    }

    componentDidMount() {
        //your code
        //MS CONNECT
        GetLoanSummaryService.getLoanSummary().then((Response) =>{
          this.setState({loansummary:Response.data})
        });
    }

    render() {
        return (
            <>
            {
                this.state.loansummary.map(
                  lnsummary =>
                  <h2 key = {lnsummary.rid}className="mb-5">{lnsummary.loanAmount}</h2>
                )
            }
            </>

        )
    }
}

export default Loansummarycard;