import React, { Component } from 'react';
import GetCreditCardbalance from '../../services/CreditCardbalanceService';

export class CreditCardbalancecard extends Component {

    constructor(props) {
        super(props)
        this.state = {
          //MS CONNECT
          creditbalance:[],
        }
    }

    componentDidMount() {
        //your code
        //MS CONNECT
        GetCreditCardbalance.getCreditBalance().then((Response) =>{
          this.setState({creditbalance:Response.data})
        });
    }

    render() {
        return (
            <>
            {
                this.state.creditbalance.map(
                  crdtbalance =>
                  <h2 key = {crdtbalance.rid}className="mb-5">{crdtbalance.creditOutstanding}</h2>
                )
            }
            </>

        )
    }
}

export default CreditCardbalancecard;