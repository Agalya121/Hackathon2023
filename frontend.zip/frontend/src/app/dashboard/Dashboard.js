import React, { Component } from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Dropdown } from 'react-bootstrap';
import ChatBot from 'react-simple-chatbot';
import Accountbalancecard from './Accountbalancecard';
import CreditCardbalancecard from './CreditCardbalancecard';
import Loansummarycard from './Loansummarycard';
import Transactioncard from './TransactionCard';



// import "react-datepicker/dist/react-datepicker.css";



export class Dashboard extends Component {


  handleChange = date => {
    this.setState({
      startDate: date
    });
  };
  constructor(props) {
    super(props)
    this.state = {
      startDate: new Date(),
      trafficData: {},
      trafficOptions: {
        responsive: true,
        animation: {
          animateScale: true,
          animateRotate: true
        },
        legend: false,
      },
      todos: [
        {
          id: 1,
          task: 'Pick up kids from school',
          isCompleted: false
        },
        {
          id: 2,
          task: 'Prepare for presentation',
          isCompleted: true
        },
        {
          id: 3,
          task: 'Print Statements',
          isCompleted: false
        },
        {
          id: 4,
          task: 'Create invoice',
          isCompleted: false
        },
        {
          id: 5,
          task: 'Call John',
          isCompleted: true
        },
        {
          id: 6,
          task: 'Meeting with Alisa',
          isCompleted: false
        }
      ],
      inputValue: '',
    }
    this.statusChangedHandler = this.statusChangedHandler.bind(this);
    this.addTodo = this.addTodo.bind(this);
    this.removeTodo = this.removeTodo.bind(this);
    this.inputChangeHandler = this.inputChangeHandler.bind(this);
  }
  statusChangedHandler(event, id) {

    //const todoIndex = this.state.todos.findIndex( t => t.id === id );
    const todo = { ...this.state.todos[id] };
    todo.isCompleted = event.target.checked;

    const todos = [...this.state.todos];
    todos[id] = todo;

    this.setState({
      todos: todos
    })
  }

  addTodo(event) {
    event.preventDefault();

    const todos = [...this.state.todos];
    todos.unshift({
      id: todos.length ? todos[todos.length - 1].id + 1 : 1,
      task: this.state.inputValue,
      isCompleted: false

    })

    this.setState({
      todos: todos,
      inputValue: ''
    })
  }

  removeTodo(index) {
    const todos = [...this.state.todos];
    todos.splice(index, 1);

    this.setState({
      todos: todos
    })
  }

  inputChangeHandler(event) {
    this.setState({
      inputValue: event.target.value
    });
  }

  componentDidMount() {
    //your code

    const newTrafficData = {
      datasets: [{
        data: [30, 30, 40],
        backgroundColor: [
          '#F08080',
          '#0096FF',
          '#40E0D0 '

        ],
        hoverBackgroundColor: [
          '#F08080',
          '#0096FF',
          '#40E0D0'

        ],
        borderColor: [
          '#F08080',
          '#0096FF',
          '#40E0D0 '

        ],
        legendColor: [
          '#F08080',
          '#0096FF',
          '#40E0D0 '

        ]
      }],

      // These labels appear in the legend and in the tooltips when hovering different arcs
      labels: [
        'Utility Bills',
        'Transportation',
        'Food',
      ]
    };
    this.setState({ trafficData: newTrafficData })
  }



  toggleProBanner() {
    document.querySelector('.proBanner').classList.toggle("hide");
  }


  render() {
    return (
      <div>
        <div className="page-header">
          <h3 className="page-title">
            <Dropdown >
              <Dropdown.Toggle variant="btn btn-danger btn-sm">
                <i className="fa fa-user-circle-o" />
                Account_1
              </Dropdown.Toggle>
              Dashboard
              <Dropdown.Menu >
                <Dropdown.Item >
                  <i className="fa fa-user-circle-o" />
                  Account_2
                </Dropdown.Item>
                <Dropdown.Item>
                  <i className="fa fa-user-circle-o" />
                  Account_3
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </h3>
          <nav aria-label="breadcrumb">
            <ul className="breadcrumb">
              <li className="breadcrumb-item active" aria-current="page">
                <span></span>Overview <i className="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
              </li>
            </ul>
          </nav>
        </div>

        <div className="row">
          <div className="col-md-3">
            <div className="card">
              <div className="card-body">
                <h4 className="card-title text-center ">Spending Analytics</h4>
                <Doughnut data={this.state.trafficData} options={this.state.trafficOptions} />
                <div id="traffic-chart-legend" className="rounded-legend legend-bottom-left  text-center  pt-4">
                  <ul>
                    <li>
                      <span className="legend-dots bg-info"></span><i class="fa fa-automobile" style={{ marginRight: "20px" }}></i>
                      <span className="legend-dots bg-success"></span><i className="fa fa-apple" style={{ marginRight: "20px" }}></i>
                      <span className="legend-dots bg-danger"></span><i className="fa fa-usb" style={{ marginRight: "20px" }}></i>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-9  ">
            <div className="row" >
              <div className="col-md-4 ">
                <div className="card bg-gradient-danger card-img-holder text-white">
                  <div className="card-body" >
                    <h4 className="font-weight-normal mb-3">Account Balance
                    </h4>
                    <Accountbalancecard />
                    {/* <h2 className="mb-5">$ 15,0000</h2> */}
                    <h6 className="card-text">Minimum Balance Maintained</h6>
                    <a class="btn btn-danger">Check your Account Details</a>
                  </div>
                </div>
              </div>
              <div className="col-md-4 ">
                <div className="card bg-gradient-info card-img-holder text-white">
                  <div className="card-body">
                    <h4 className="font-weight-normal mb-3">Credit Outstanding
                    </h4>
                    <CreditCardbalancecard />
                    {/* <h2 className="mb-5">$45,6334</h2> */}
                    <h6 className="card-text">Healthy credit score maintained</h6>
                    <a class="btn btn-info">Check your Credit score</a>
                  </div>
                </div>
              </div>
              <div className="col-md-4 ">
                <div className="card bg-gradient-success card-img-holder text-white">
                  <div className="card-body">
                    <h4 className="font-weight-normal mb-3">Loans
                    </h4>
                    <Loansummarycard />
                    {/* <h2 className="mb-5">95,5741</h2> */}
                    <h6 className="card-text">Monthly EMI payment</h6>
                    <a class="btn btn-success" >Check your interest rate</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="row">
          <div className="col-3 text-center" style={{ marginTop: "36px" }}>
            <div className="card" >
              <div className="card-header text-center border bg-gradient-danger text-white" ><h3>Exciting New Offer on Loans!!!!</h3></div>
              <div className="card-body">
                <p >Thanks to your increased credit score we are now ready to give you 2 lakhs loan without any paper work.</p>
                <p>
                  <a class="btn bg-gradient-danger" href="#" role="button">Learn more</a>
                </p>

              </div>
            </div>

          </div>

          <div className="col-6 d-flex justify-content-center" >
            <div className="card text-center" style={{ marginTop: "40px", background: "#f2edf3", border: "1px" }}>
              <h3 className="card-header bg-gradient-danger text-white" >Interactions</h3>
              <div class="card text-center " style={{ maxHeight: "350px", overflow: "auto" }}>
              <Transactioncard/>
                {/* <div class="card text-center  border" style={{ width: "650px", marginBottom: "15px" }}>
                  <div class="card-header bg-gradient-success text-white">
                    IMPS
                  </div>
                  <div class="card-body" >
                    <h4 class="card-title">You have made IMPS Transaction of Amount 35000 for Utility from  XXXXXXXXX9967 to Sobha Apartment,Bangalore on 11/02/2023 11:53:00</h4>
                    <a class="btn btn-success">Report</a>
                    <a class="btn btn-success">Mark as Regular</a>
                    <a class="btn btn-success">Check your Balance</a>
                  </div>
                  <div class="card-footer text-muted">
                    5 mins ago
                  </div>
                </div> */}
                {/* <div class="card text-center  border" style={{ width: "650px", marginBottom: "15px" }}>
                  <div class="card-header bg-gradient-danger text-white ">
                    UPI
                  </div>
                  <div class="card-body" >
                    <p class="card-title" >You have made  UPI Transaction of  Amount 500 for food from XXXXXXXXX9967 via phonepe to Bangalore Cafe,Bangalore  on 11/02/2023 11:15:00</p>
                    <a class="btn bg-danger">Send Again</a>
                    <a class="btn bg-danger">Mark as Regular</a>
                    <a class="btn bg-danger">Report</a>
                  </div>
                  <div class="card-footer text-muted">
                    35 mins ago
                  </div>
                </div> */}
                {/* <div class="card text-center  border" style={{ width: "650px", marginBottom: "15px" }}>
                  <div class="card-header bg-gradient-success text-white ">
                    DD
                  </div>
                  <div class="card-body" >
                    <h4 class="card-title">You have made a Direct Debt of Amount 150000 for Education from  XXXXXXXXX9967 to ABC university,Bangalore on  11/02/2023 11:03:00</h4>
                    <a class="btn btn-success">Report</a>
                    <a class="btn btn-success">Mark as Regular</a>
                    <a class="btn btn-success">Check your Balance</a>
                  </div>
                  <div class="card-footer text-muted">
                    1 hour ago
                  </div>
                </div> */}
                {/* <div class="card text-center  border" style={{ width: "650px", marginBottom: "15px" }}>
                  <div class="card-header bg-gradient-info text-white ">
                    Credit card
                  </div>
                  <div class="card-body" >
                    <h4 class="card-title">You have made a Credit card Transaction of Amount 150000 for Utility from card XXXXXXXXX0009 to Abc,Bangalore on 10/02/2023 23:04:23</h4>
                    <a class="btn btn-info">Report</a>
                    <a class="btn btn-info">Block the card</a>
                    <a class="btn btn-info">Mark as Regular</a>
                  </div>
                  <div class="card-footer text-muted">
                    1 day ago
                  </div>
                </div> */}
              </div>
            </div>
          </div>

          <div className="col -3" style={{ marginTop: "36px" }} >
            <div className="card" >
              <div className="card-header text-center border bg-gradient-danger text-white" ><h3>Find Accounts</h3></div>
              <div className="card-body">
                <div>
                  <div className="row">
                    <div className="col">
                      <i className="fa fa-user-circle-o" ></i>
                    </div>
                    <div className="col">
                      <h5>Thomas</h5>
                    </div>
                    <div className="col">
                      <a href="#">Connect</a>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col">
                      <i className="fa fa-user-circle-o" ></i>
                    </div>
                    <div className="col">
                      <h5>Catherine</h5>
                    </div>
                    <div className="col">
                      <a href="#">Connect</a>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col">
                      <i className="fa fa-user-circle-o" ></i>
                    </div>
                    <div className="col">
                      <h5>Philip</h5>
                    </div>
                    <div className="col">
                      <a href="#">Connect</a>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col">
                      <i className="fa fa-user-circle-o" ></i>
                    </div>
                    <div className="col">
                      <h5>Gloria</h5>
                    </div>
                    <div className="col">
                      <a href="#">Connect</a>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col">
                      <i className="fa fa-user-circle-o" ></i>
                    </div>
                    <div className="col">
                      <h5>Donald</h5>
                    </div>
                    <div className="col">
                      <a href="#">Connect</a>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col">
                      <i className="fa fa-user-circle-o" ></i>
                    </div>
                    <div className="col">
                      <h5>Maria</h5>
                    </div>
                    <div className="col">
                      <a href="#">Connect</a>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col">
                      <i className="fa fa-user-circle-o" ></i>
                    </div>
                    <div className="col">
                      <h5>Lya</h5>
                    </div>
                    <div className="col">
                      <a href="#">Connect</a>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col">
                    <i class="fa fa-empire"></i>
                    </div>
                    <div className="col">
                      <h5>z Cafe</h5>
                    </div>
                    <div className="col">
                      <a href="#">Connect</a>
                    </div>
                  </div>



                </div>

              </div>
            </div>
          </div>
        </div>

        <div className="row" style={{marginTop:"30px"}}>
          <div className="col-12 text-center">
          <div className="card">
            <div className="card-header bg-gradient-danger text-white"><h3>Happy Anniversary!!!!</h3></div>
            <div className="card-body"><h4>Thanks for being with us for past one year!!!</h4>
            <p>Please use the code <a href="#">anniversary01</a> at your favorite cafe to get 50% off on your bill</p>
            </div>
          </div>
          </div>
        </div>


        <ChatBot
          // This appears as the header
          // text for the chat bot
          headerTitle="Personal Relationship Manager"
          speechSynthesis={{ enable: true, lang: 'en' }}
          steps={steps}
          {...config}

        />
      </div>
    );
  }
}
const steps = [
  {
    id: '0',
    message: 'Hey!',

    // This calls the next id
    // i.e. id 1 in this case
    trigger: '1',
  }, {
    id: '1',

    // This message appears in
    // the bot chat bubble
    message: 'I am your Personal Relationship Manager,I will be assiting you',
    trigger: '2'
  }, {
    id: '2',

    // Here we want the user
    // to enter input
    user: true,
    trigger: '4',
  }, {
    id: 4,
    options: [

      // When we need to show a number of
      // options to choose we create alist
      // like this
      { value: 1, label: 'Do you want me to move forward' },
      { value: 2, label: 'Bring in a colleague' },
     


    ],
    end: true
  }

];

// Set some properties of the bot
const config = {
  floating: true,
};
export default Dashboard;