import React, { Component } from 'react';
import GetAccountBalance from '../../services/AccountBalanceService';

export class Accountbalancecard extends Component {

    constructor(props) {
        super(props)
        this.state = {
          //MS CONNECT
          accountbalance:[],
        }
    }

    componentDidMount() {
        //your code
        //MS CONNECT
        GetAccountBalance.getAccountBalance().then((Response) =>{
          this.setState({accountbalance:Response.data})
        });
    }

    render() {
        return (
            <>
            {
                this.state.accountbalance.map(
                  accntbalance =>
                  <h2 key = {accntbalance.rid}className="mb-5">{accntbalance.totalAmount}</h2>
                )
            }
            </>

        )
    }
}

export default Accountbalancecard;